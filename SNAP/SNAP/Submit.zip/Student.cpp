#include "Student.h"

Student::Student() {
	studID = "0";
}
string Student::getStudID() const {
	return studID;
}